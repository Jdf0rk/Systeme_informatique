/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/djebli/Bureau/Systeme_informatique-master/Compilateur/Banc_Registre/banc_registre.vhd";
extern char *IEEE_P_3620187407;

int ieee_p_3620187407_sub_5109402382352621412_3965413181(char *, char *, char *);


static void work_a_0926557375_3212880686_p_0(char *t0)
{
    char t19[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned int t9;
    char *t10;
    unsigned char t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    int t20;
    unsigned int t21;
    int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4440);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1832U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    if (t7 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB10;

LAB12:
LAB11:    goto LAB3;

LAB5:    xsi_set_current_line(57, ng0);
    t1 = xsi_get_transient_memory(128U);
    memset(t1, 0, 128U);
    t8 = t1;
    t9 = (8U * 1U);
    t10 = t8;
    memset(t10, (unsigned char)2, t9);
    t11 = (t9 != 0);
    if (t11 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 4552);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t1, 128U);
    xsi_driver_first_trans_fast(t13);
    goto LAB6;

LAB8:    t12 = (128U / t9);
    xsi_mem_set_data(t8, t8, t9, t12);
    goto LAB9;

LAB10:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t1 = (t0 + 1352U);
    t8 = *((char **)t1);
    t9 = (3 - 3);
    t12 = (t9 * 1U);
    t18 = (0 + t12);
    t1 = (t8 + t18);
    t10 = (t19 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 3;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t20 = (0 - 3);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t21;
    t22 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t1, t19);
    t23 = (t22 - 0);
    t21 = (t23 * 1);
    t24 = (8U * t21);
    t25 = (0U + t24);
    t13 = (t0 + 4552);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8U);
    xsi_driver_first_trans_delta(t13, t25, 8U, 0LL);
    goto LAB11;

}

static void work_a_0926557375_3212880686_p_1(char *t0)
{
    char t22[16];
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;
    int t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 7784U);
    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t4 = (t0 + 7752U);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t2, t5, t4);
    if (t6 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t16 = (t0 + 2472U);
    t17 = *((char **)t16);
    t16 = (t0 + 1032U);
    t18 = *((char **)t16);
    t19 = (3 - 3);
    t20 = (t19 * 1U);
    t21 = (0 + t20);
    t16 = (t18 + t21);
    t23 = (t22 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = 3;
    t24 = (t23 + 4U);
    *((int *)t24) = 0;
    t24 = (t23 + 8U);
    *((int *)t24) = -1;
    t25 = (0 - 3);
    t26 = (t25 * -1);
    t26 = (t26 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t26;
    t27 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t16, t22);
    t28 = (t27 - 0);
    t26 = (t28 * 1);
    xsi_vhdl_check_range_of_index(0, 15, 1, t27);
    t29 = (8U * t26);
    t30 = (0 + t29);
    t24 = (t17 + t30);
    t31 = (t0 + 4616);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    memcpy(t35, t24, 8U);
    xsi_driver_first_trans_fast_port(t31);

LAB2:    t36 = (t0 + 4456);
    *((int *)t36) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1672U);
    t11 = *((char **)t7);
    t7 = (t0 + 4616);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 8U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t7 = (t0 + 1512U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t1 = t10;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_0926557375_3212880686_p_2(char *t0)
{
    char t22[16];
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;
    int t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 7784U);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t4 = (t0 + 7768U);
    t6 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t2, t5, t4);
    if (t6 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t16 = (t0 + 2472U);
    t17 = *((char **)t16);
    t16 = (t0 + 1192U);
    t18 = *((char **)t16);
    t19 = (3 - 3);
    t20 = (t19 * 1U);
    t21 = (0 + t20);
    t16 = (t18 + t21);
    t23 = (t22 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = 3;
    t24 = (t23 + 4U);
    *((int *)t24) = 0;
    t24 = (t23 + 8U);
    *((int *)t24) = -1;
    t25 = (0 - 3);
    t26 = (t25 * -1);
    t26 = (t26 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t26;
    t27 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t16, t22);
    t28 = (t27 - 0);
    t26 = (t28 * 1);
    xsi_vhdl_check_range_of_index(0, 15, 1, t27);
    t29 = (8U * t26);
    t30 = (0 + t29);
    t24 = (t17 + t30);
    t31 = (t0 + 4680);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    memcpy(t35, t24, 8U);
    xsi_driver_first_trans_fast_port(t31);

LAB2:    t36 = (t0 + 4472);
    *((int *)t36) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1672U);
    t11 = *((char **)t7);
    t7 = (t0 + 4680);
    t12 = (t7 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 8U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB5:    t7 = (t0 + 1512U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t1 = t10;
    goto LAB7;

LAB9:    goto LAB2;

}


extern void work_a_0926557375_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0926557375_3212880686_p_0,(void *)work_a_0926557375_3212880686_p_1,(void *)work_a_0926557375_3212880686_p_2};
	xsi_register_didat("work_a_0926557375_3212880686", "isim/test_reg_isim_beh.exe.sim/work/a_0926557375_3212880686.didat");
	xsi_register_executes(pe);
}
