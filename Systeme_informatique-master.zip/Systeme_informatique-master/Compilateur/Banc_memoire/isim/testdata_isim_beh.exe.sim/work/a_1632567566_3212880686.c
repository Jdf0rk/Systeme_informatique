/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/djebli/Bureau/Systeme_informatique-master/Compilateur/Banc_memoire/data_memory.vhd";
extern char *IEEE_P_3620187407;

int ieee_p_3620187407_sub_5109402382352621412_3965413181(char *, char *, char *);


static void work_a_1632567566_3212880686_p_0(char *t0)
{
    char t19[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned int t9;
    char *t10;
    unsigned char t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    int t20;
    unsigned int t21;
    int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;

LAB0:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3464);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1512U);
    t5 = *((char **)t1);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    if (t7 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB10;

LAB11:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB12;

LAB13:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(55, ng0);
    t1 = xsi_get_transient_memory(2048U);
    memset(t1, 0, 2048U);
    t8 = t1;
    t9 = (8U * 1U);
    t10 = t8;
    memset(t10, (unsigned char)2, t9);
    t11 = (t9 != 0);
    if (t11 == 1)
        goto LAB8;

LAB9:    t13 = (t0 + 3544);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t1, 2048U);
    xsi_driver_first_trans_fast(t13);
    goto LAB6;

LAB8:    t12 = (2048U / t9);
    xsi_mem_set_data(t8, t8, t9, t12);
    goto LAB9;

LAB10:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 1992U);
    t5 = *((char **)t1);
    t1 = (t0 + 1032U);
    t8 = *((char **)t1);
    t9 = (7 - 7);
    t12 = (t9 * 1U);
    t18 = (0 + t12);
    t1 = (t8 + t18);
    t10 = (t19 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 7;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t20 = (0 - 7);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t21;
    t22 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t1, t19);
    t23 = (t22 - 0);
    t21 = (t23 * 1);
    xsi_vhdl_check_range_of_index(0, 255, 1, t22);
    t24 = (8U * t21);
    t25 = (0 + t24);
    t13 = (t5 + t25);
    t14 = (t0 + 3608);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t26 = *((char **)t17);
    memcpy(t26, t13, 8U);
    xsi_driver_first_trans_delta(t14, 0U, 8U, 0LL);
    goto LAB6;

LAB12:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 1192U);
    t5 = *((char **)t1);
    t1 = (t0 + 1032U);
    t8 = *((char **)t1);
    t9 = (7 - 7);
    t12 = (t9 * 1U);
    t18 = (0 + t12);
    t1 = (t8 + t18);
    t10 = (t19 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 7;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t20 = (0 - 7);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t21;
    t22 = ieee_p_3620187407_sub_5109402382352621412_3965413181(IEEE_P_3620187407, t1, t19);
    t23 = (t22 - 0);
    t21 = (t23 * 1);
    t24 = (8U * t21);
    t25 = (0U + t24);
    t13 = (t0 + 3544);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t5, 8U);
    xsi_driver_first_trans_delta(t13, t25, 8U, 0LL);
    goto LAB6;

}


extern void work_a_1632567566_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1632567566_3212880686_p_0};
	xsi_register_didat("work_a_1632567566_3212880686", "isim/testdata_isim_beh.exe.sim/work/a_1632567566_3212880686.didat");
	xsi_register_executes(pe);
}
