# Systeme_informatique



        Configuration instructions:
        Installation instructions:
        Operating instructions:
        A file manifest:
        Copyright and licensing information:
        Contact information for the distributor or programmer:
        Known bugs:
        Troubleshooting:
        Credits and acknowledgements:
        A changelog:

