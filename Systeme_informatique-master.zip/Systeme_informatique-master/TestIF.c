int main(int a,int b)
{
	int a=5;	
	int b=10;
	if (a==5){
		b=8;
	}
	if (b>9){
		a=2;
	}
}

