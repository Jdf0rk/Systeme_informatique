int main(int a, int b)
{
	int a;
	a=5;		
	int i = 15;
	a=5;	
	a = c + 2;		
	int vae = 5;	
	int ette;	
	ette = 21;	
}
