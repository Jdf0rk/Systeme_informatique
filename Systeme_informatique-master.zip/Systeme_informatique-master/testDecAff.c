int main()
{
	int a;
	a=5;		
	int i = 15;	
	int i= 5;	
	a=2;		
	int vae = 5;	
	int ette;	
	ette = 21;	
}
