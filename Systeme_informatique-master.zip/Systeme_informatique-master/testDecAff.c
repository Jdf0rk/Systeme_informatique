int main()
{
	int a_8aA9_P=1;
	int A;
	a=5;		
	int i = 15;				
	int vae = 5;	
	int ette;	
	etTe = 21;	
}
int maan()
{
	int abv=1;	
}
