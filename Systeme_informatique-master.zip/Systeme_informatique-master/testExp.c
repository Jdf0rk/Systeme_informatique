int main()
{
	int a=15;
	a = 1+1;
	a = 2*8;
	int b=15*3;
	a=a+b-3;	
}
