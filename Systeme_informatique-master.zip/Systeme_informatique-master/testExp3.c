int main()
{
	int b=1;
	int a=-(b+1)*2;
	a=1*((2-3)*(5*(6+7)));
}
