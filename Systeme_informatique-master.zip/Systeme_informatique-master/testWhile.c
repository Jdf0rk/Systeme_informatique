int main(int a,int b)
{
	int a=1;
	while(a<5){
		a=a+1;
	}
	a=10;
}

